package com.pradeep.cms.data;

import java.util.HashMap;
import java.util.Map;

import com.pradeep.cms.model.Customer;

public enum CustomerMap {
INSTANCE;
	
private Map<Integer,Customer> map;

private CustomerMap() {
map=new HashMap<>();
Customer c1=new Customer("pradeep","chinchole","Male","pradeep@gmail.com",
		        "shivane","pune","Maharashtra");


Customer c2=new Customer("ram","chinchole","Male","ram@gmail.com",
        "shivane","mumbai","Maharashtra");


Customer c3=new Customer("rajesh","chinchole","Male","rajesh@gmail.com",
        "shivane","solapur","Maharashtra");


map.put(c1.getCustomerId(),c1);
map.put(c2.getCustomerId(),c2);
map.put(c3.getCustomerId(),c3);
	
}
	

public Map<Integer, Customer> getMap() {
	return map;
}
	
}
