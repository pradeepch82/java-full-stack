package com.rest.controllers;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/resttest")
@RestController
public class SpringRestTestController {
	
	public SpringRestTestController() {
		System.out.println("Rest Test Controller created....");
		}
		
	    @RequestMapping("/printrest")
	    public String printMessage(){
	    	return "Inside Print Rest Method";
	    }
	
		@GetMapping("/getrest")
		public String hiGET(){
			return "Inside GET Method";
		}
		
		@PostMapping("/postrest")
		public String hiPOST(){
			return "Inside POST MethodT";
		}
		
		
		@DeleteMapping("/deletetest")
		public String hiDELETE(){
			return "Inside DELETE Method";
		}
		
		@PutMapping("/puttest")
		public String hiPUT(){
			return "Inside PUT Method";
		}
		
		@PatchMapping("/patchtest")
		public String hiPATCH(){
			return "Inside PATCH Method";
		}

}
