package com.spring.controllers;

import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class SpringTestController {
	
	
	public SpringTestController(){
		System.out.println("Spring Test Controller is created");
	}
	
	@RequestMapping("/welcome")
	public @ResponseBody String welcome(){
		return "Welcome at SoftEdge IT";
	}
	
	@RequestMapping("/mavtest")
	public ModelAndView mavTest(){
		return new ModelAndView("mav","message","Welcome at SoftEdge IT Services");
	}

    @RequestMapping(value="/gettest",method=RequestMethod.GET)
	public ModelAndView getTest(){
		return new ModelAndView("gettest","message", "GET Method Test Successful on " + new Date());
	}

    @RequestMapping(value="/posttest",method=RequestMethod.POST)
	public  @ResponseBody String postTest(){
		return "Post Method Test Successful on :" + new Date();
	}
    
	
	
}
