package com.pradeep.cms.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.pradeep.cms.model.Customer;
import com.pradeep.cms.service.CustomerService;




@RequestMapping("/spring")
@Controller
//@Component
public class CustomerSpringController {


	@Qualifier("cmrsi")
	@Autowired
	private CustomerService cs; // dependency

	public CustomerSpringController() {
		System.out.println("CustomerSpringController created...");
	}

	
  @RequestMapping(value="/getallcustomers",method=RequestMethod.GET)	
  public String getAllCustomer(ModelMap map){
	  map.addAttribute("customers", cs.getAllCustomers());	  
	  return "customerList";
  }
  
  
  @RequestMapping(value="/delete/{id}",method=RequestMethod.GET)	
  public String delete(@PathVariable("id") int customerId, ModelMap map){
	  cs.removeCustomer(customerId);
	   map.addAttribute("customers", cs.getAllCustomers());
	   return "customerList";
  }
  

  @RequestMapping(value="/edit",method=RequestMethod.GET)	
  public String editCustomer(@RequestParam("customerId") int customerId, ModelMap map){
	  
	  map.addAttribute("customer",  cs.getCustomer(customerId));
	  map.addAttribute("customers", cs.getAllCustomers());
	  
	   return "editCustomer";
  }
  


  @RequestMapping(value="/new",method=RequestMethod.GET)	
  public String newCustomer( ModelMap map){
	  
	  map.addAttribute("customer",  new Customer());
	  map.addAttribute("customers", cs.getAllCustomers());
	  
	   return "addCustomer";
  }
  
  

  @RequestMapping(value="/update",method=RequestMethod.POST)	
  public ModelAndView editCustomer(@ModelAttribute("customer") Customer customer){
	  
	  cs.updateCustomer(customer);
	  
	  return new ModelAndView("customerList","customers",cs.getAllCustomers());
  }
  
  @RequestMapping(value="/add",method=RequestMethod.POST)	
  public ModelAndView addCustomer(@ModelAttribute("customer") Customer customer){
	  cs.addCustomer(customer); 
	  
	  return new ModelAndView("customerList","customers",cs.getAllCustomers());
  }
  
  
  
  
}




