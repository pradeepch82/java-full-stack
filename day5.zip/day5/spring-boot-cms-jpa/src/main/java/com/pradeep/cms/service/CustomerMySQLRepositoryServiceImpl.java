package com.pradeep.cms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.pradeep.cms.dao.CustomerDao;
import com.pradeep.cms.dao.CustomerRepository;
import com.pradeep.cms.model.Customer;

@Service("cmrsi")
// @Component
public class CustomerMySQLRepositoryServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepository repository;

	public CustomerMySQLRepositoryServiceImpl() {
		System.out.println("CustomerMySQLRepositoryServiceImpl  created....");
	}

	@Override
	public boolean addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return repository.save(customer) == customer;
	}

	@Override
	public boolean removeCustomer(int customerId) {
		Customer c1 = repository.findById(customerId).get();

		if (c1 != null) {
			repository.delete(c1);
			return true;
		}

		return false;
	}

	@Override
	public boolean updateCustomer(Customer customer) {

		Customer c1 = repository.findById(customer.getCustomerId()).get();
		;

		if (c1 != null) {
			repository.save(customer);
			return true;
		}

		return false;

	}

	@Override
	public Customer getCustomer(int customerId) {
		// TODO Auto-generated method stub
		return repository.findById(customerId).get();
	}

	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

}
