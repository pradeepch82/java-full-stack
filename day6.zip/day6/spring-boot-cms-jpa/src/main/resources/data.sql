insert into users(username, password, enabled)values('pradeep','$2a$10$LvLqGSYjOlTicENx.CTAkuCbRGGQeNieqVIQAxNTPFwXcEn3CuhiK',true);
insert into authorities(username,authority)values('pradeep','ROLE_ADMIN');
 
insert into users(username, password, enabled)values('ram','$2a$10$dn7KQBRgBeIGp7fXUj/K/e53B7cccjkRK56H0li8YhVcT6nBRuhDa',true);
insert into authorities(username,authority)values('ram','ROLE_USER');


insert into users(username, password, enabled)values('raj','$2a$10$0olmvmwaviJF.tQd5UPvKeobUxYTiz3.rCRYV42riysFNvO2pbY9a',true);
insert into authorities(username,authority)values('raj','ROLE_STUDENT');


insert into users(username, password, enabled)values('india','$2a$10$0olmvmwaviJF.tQd5UPvKeobUxYTiz3.rCRYV42riysFNvO2pbY9a',true);
insert into authorities(username,authority)values('india','TEACHER');


