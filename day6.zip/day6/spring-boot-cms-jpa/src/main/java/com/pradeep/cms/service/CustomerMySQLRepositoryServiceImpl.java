package com.pradeep.cms.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.pradeep.cms.dao.CustomerRepository;
import com.pradeep.cms.model.Customer;

@Service("cmrsi")
// @Component
public class CustomerMySQLRepositoryServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepository repository;

	public CustomerMySQLRepositoryServiceImpl() {
		System.out.println("CustomerMySQLRepositoryServiceImpl  created....");
	}

	@Override
	public boolean addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return repository.save(customer) == customer;
	}

	@Override
	public boolean removeCustomer(int customerId) {
		Customer c1 = repository.findById(customerId).get();

		if (c1 != null) {
			repository.delete(c1);
			return true;
		}

		return false;
	}

	@Override
	public boolean updateCustomer(Customer customer) {

		Customer c1 = repository.findById(customer.getCustomerId()).get();
		;

		if (c1 != null) {
			repository.save(customer);
			return true;
		}

		return false;

	}

	@Override
	public Customer getCustomer(int customerId) {
		
	
        
		// TODO Auto-generated method stub
		return repository.findById(customerId).get();
	
	
	
	}

	@Override
	public List<Customer> getAllCustomers() {
		
		/*Pageable paging = PageRequest.of(0, 2, Sort.by("firstName"));
		 
        Page<Customer> pagedResult = repository.findAll(paging);
        
        if(pagedResult.hasContent()) {
            return pagedResult.getContent();
        } else {
            return new ArrayList<Customer>();
        }*/
    
		return repository.findAll();
	}

	@Override
	public List<Customer> getAllCustomersByCity(String city) {
		// TODO Auto-generated method stub
		return repository.findAllByCity(city);
	}

	@Override
	public List<Customer> getAllCustomersByAddress(String address) {
		// TODO Auto-generated method stub
		return repository.findAllByAddress(address);
	}

	@Override
	public List<Customer> getAllCustomersByState(String state) {
		// TODO Auto-generated method stub
		return repository.findAllByState(state);
	}

	
	
	
	
	
	
}
