package com.controllers;

import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;



@Controller
public class SpringController {

	public SpringController() {
	System.out.println("Spring Controller created......");
	}
	
    @RequestMapping("/hello")
	public String hello(){
		return "hello";
	}
    
    
	
    @RequestMapping("/welcome")
	public ModelAndView welcome(){
		return new ModelAndView("welcome","message", "Welcome To Spring Web MVC at Softedge");
	}
    
    
    @RequestMapping(value="/greet",method=RequestMethod.GET)
	public ModelAndView greet(){
		return new ModelAndView("greet","message", "Greting of the day "+new Date());
	}
    
    

    @RequestMapping(value="/today",method=RequestMethod.GET)
	public  @ResponseBody String today(){
		return "Today is  :"+new Date();
	}
    
}
