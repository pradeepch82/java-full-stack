package com.pradeep.cms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.pradeep.cms.dao.CustomerDao;
import com.pradeep.cms.model.Customer;

@Service
//@Component
public class CustomerServiceImpl implements CustomerService {

	
@Qualifier("mySQLCustomerDaoImpl")
@Autowired
private CustomerDao customerDao; //dependency


	
public CustomerServiceImpl() {
System.out.println("CustomerServiceImpl created....");
}
	
	/*
  //constructor injection
	public CustomerServiceImpl(CustomerDao customerDao) {
	this.customerDao = customerDao;
	System.out.println("CustomerServiceImpl param costrucxtor created....");
   	}

	
	//@Qualifier("mySQLCustomerDaoImpl")
	//@Autowired
	//setter injection
	public void setCustomerDao(CustomerDao customerDao) {
		this.customerDao = customerDao;
	
		System.out.println("CustomerServiceImpl setCustomerDao created....");
	   	}


*/

	@Override
	public boolean addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return customerDao.addCustomer(customer);
	}

	@Override
	public boolean removeCustomer(int customerId) {
		// TODO Auto-generated method stub
		return customerDao.removeCustomer(customerId);
	}

	@Override
	public boolean updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return customerDao.updateCustomer(customer);
	}

	@Override
	public Customer getCustomer(int customerId) {
		// TODO Auto-generated method stub
		return customerDao.getCustomer(customerId);
	}

	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return customerDao.getAllCustomers();
	}

}
