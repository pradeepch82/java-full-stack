package com.pradeep.cms.service;

import java.util.List;

import com.pradeep.cms.model.Customer;

public interface CustomerService {
	boolean addCustomer(Customer customer);
	boolean removeCustomer(int customerId);
	boolean updateCustomer(Customer customer);
	Customer getCustomer(int customerId);
	List<Customer> getAllCustomers();
		
	
}
