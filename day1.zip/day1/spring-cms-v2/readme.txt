
Customer
========

customerId (auto generated)
firstName
lastName
gender
email
address
city
state



CustomerMainApp
         CustomerService
                 CustomerDao
                          CustomerMap







Product
========
productId (auto genrated)
productName
price



ProductMainApp
         ProductService
                 ProductDao
                          ProductMap





                          BeanFactory (I)
                              |   -XMLBeanFactory (C)
                        ApplicationContext (I)
                        
  ClassPathXMLApplicationXContext (C)     AnnotationConfigApplicationContext(C)
                              |
                       ServletWebApplicationContext    





IOC

DI
  setter   ->    <property name="cs" ref="customerService">
  constructor -> <constructor-arg   name="cs" ref="customerService">
                          
                                                    
Spring Bean Life Cycle
==========================
1.Instantiation
2.Dependency Injection
3.Initialization
4.Service
5.Destruction


Spring Bean Scope : singletone|prototype|request|session






