package com.pradeep.cms.presentation;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

import com.pradeep.cms.dao.MapCustomerDaoImpl;
import com.pradeep.cms.model.Customer;
import com.pradeep.cms.service.CustomerService;
import com.pradeep.cms.service.CustomerServiceImpl;

public class CustomerMainApp {

	private CustomerService cs; // dependency

	public CustomerMainApp() {
		System.out.println("CustomerMainApp created...");
	}

	// constructor
	public CustomerMainApp(CustomerService cs) {
		this.cs = cs;
		System.out.println("CustomerMainApp param constrcutor...");
	}

	// setter injection
	public void setCs(CustomerService cs) {
		this.cs = cs;
		System.out.println("CustomerMainApp setCs method..........");
	}

	public void addCustomer(Customer customer) {

		if (cs.addCustomer(customer))
			System.out.println(customer + "   added successfully");
		else
			System.out.println("Problme in adding customer...");
	}

	public void updateCustomer(Customer customer) {

		if (cs.updateCustomer(customer))
			System.out.println(customer + "   updated successfully");
		else
			System.out.println("customer not found...");
	}

	public void deleteCustomer(int customerId) {

		if (cs.removeCustomer(customerId))
			System.out.println(customerId + "   deleted successfully");
		else
			System.out.println("customer not found...");
	}

	public void showCustomer(int customerId) {

		Customer customer = cs.getCustomer(customerId);

		if (customer != null)
			System.out.println("Customer Details \n" + customer);
		else
			System.out.println("customer not found...");
	}

	public void showAll() {
		System.out.println("All Customers\n===============================");

		for (Customer c : cs.getAllCustomers())
			System.out.println(c);

	}
	
	
	public void init(){
		System.out.println("........CustomerMainApp initialized......");
	}
	
	
	public void destroy(){
		System.out.println("........CustomerMainApp destroyed......");
	}
	

	public static void main(String[] args) {

		
		//XmlBeanFactory factory=new XmlBeanFactory(new ClassPathResource("beans.xml"));
		//System.out.println("Core container created...");
		System.out.println("======================");
		ClassPathXmlApplicationContext c=new ClassPathXmlApplicationContext("beans.xml");
		System.out.println("Advanced container created...");
		
		
		//CustomerMainApp cma=c.getBean(CustomerMainApp.class);
		
		CustomerMainApp cma=(CustomerMainApp)c.getBean("customerMainApp");
		CustomerMainApp cma2=(CustomerMainApp)c.getBean("customerMainApp");
		
		CustomerMainApp cma1=(CustomerMainApp)c.getBean("customerMainApp1");
		
		System.out.println(cma.hashCode());
		System.out.println(cma1.hashCode());
		
		
		cma.showAll();
		
		
		//stop the container
		c.registerShutdownHook();
		
		
	}
}




