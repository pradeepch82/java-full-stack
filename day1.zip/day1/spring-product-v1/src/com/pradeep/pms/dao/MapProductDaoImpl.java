package com.pradeep.pms.dao;

import java.util.ArrayList;
import java.util.List;

import com.pradeep.pms.data.ProductMap;
import com.pradeep.pms.model.Product;

public class MapProductDaoImpl implements ProductDao {

	public MapProductDaoImpl() {
		System.out.println("MapProductDaoImpl created.....");
	}

	@Override
	public boolean addProduct(Product product) {

		return ProductMap.INSTANCE.getMap().put(product.getProductId(), product) == product;
	}

	@Override
	public boolean updateProduct(Product product) {

		if (ProductMap.INSTANCE.getMap().containsKey(product.getProductId())) {
			ProductMap.INSTANCE.getMap().put(product.getProductId(), product);
			return true;
		}

		return false;
	}

	@Override
	public boolean deleteProduct(int productId) {

		if (ProductMap.INSTANCE.getMap().containsKey(productId)) {
			ProductMap.INSTANCE.getMap().remove(productId);
			return true;
		}

		return false;
	}

	@Override
	public Product getProduct(int productId) {
		// TODO Auto-generated method stub
		return ProductMap.INSTANCE.getMap().get(productId);
	}

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return new ArrayList<>(ProductMap.INSTANCE.getMap().values());
	}

}
