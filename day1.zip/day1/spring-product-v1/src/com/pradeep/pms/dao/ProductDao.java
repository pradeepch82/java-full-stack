package com.pradeep.pms.dao;

import java.util.List;

import com.pradeep.pms.model.Product;

public interface ProductDao {

	boolean addProduct(Product product);
	boolean updateProduct(Product product);
	boolean deleteProduct(int productId);
	Product getProduct(int productId);
	List<Product> getAllProducts();

}
