package com.pradeep.pms.data;

import java.util.HashMap;
import java.util.Map;

import com.pradeep.pms.model.Product;

public enum ProductMap {

	INSTANCE;
	
	private Map<Integer, Product> map;
	
	private ProductMap() {
	map=new HashMap<>();
	
	Product p1=new Product("Mobile", 24000.55);
	Product p2=new Product("Shirt", 4000.55);
	Product p3=new Product("Router",3000.55);
	Product p4=new Product("Laptop", 54000.55);
	Product p5=new Product("Camera", 54000.55);
	
	map.put(p1.getProductId(), p1);
	map.put(p2.getProductId(), p2);
	map.put(p3.getProductId(), p3);
	map.put(p4.getProductId(), p4);
	map.put(p5.getProductId(), p5);
		
	}
	
	public Map<Integer, Product> getMap() {
		return map;
	}
	
	
	
	
}
