package com.pradeep.pms.service;

import java.util.List;

import com.pradeep.pms.model.Product;

public interface ProductService {
	boolean addProduct(Product product);
	boolean updateProduct(Product product);
	boolean deleteProduct(int productId);
	Product getProduct(int productId);
	List<Product> getAllProducts();
}
