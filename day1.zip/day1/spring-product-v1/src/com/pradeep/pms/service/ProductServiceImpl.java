package com.pradeep.pms.service;

import java.util.List;

import com.pradeep.pms.dao.ProductDao;
import com.pradeep.pms.model.Product;

public class ProductServiceImpl implements ProductService {

	// dependency
	private ProductDao productDao;

	public ProductServiceImpl() {
		System.out.println("ProductServiceImpl created...");
	}

	// constructor injection
	public ProductServiceImpl(ProductDao productDao) {
		this.productDao = productDao;
		System.out.println("ProductServiceImpl  param constructor....");

	}

	// setter injection
	public void setProductDao(ProductDao productDao) {
		this.productDao = productDao;
		System.out.println("ProductServiceImpl  setProductDao method.......");
	}

	@Override
	public boolean addProduct(Product product) {
		// TODO Auto-generated method stub
		return productDao.addProduct(product);
	}

	@Override
	public boolean updateProduct(Product product) {
		// TODO Auto-generated method stub
		return productDao.updateProduct(product);
	}

	@Override
	public boolean deleteProduct(int productId) {
		// TODO Auto-generated method stub
		return productDao.deleteProduct(productId);
	}

	@Override
	public Product getProduct(int productId) {
		// TODO Auto-generated method stub
		return productDao.getProduct(productId);
	}

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return productDao.getAllProducts();
	}

}
