package com.pradeep.pms.presentation;

import com.pradeep.pms.dao.MapProductDaoImpl;
import com.pradeep.pms.model.Product;
import com.pradeep.pms.service.ProductService;
import com.pradeep.pms.service.ProductServiceImpl;

public class ProductManinApp {

private ProductService ps;

public ProductManinApp() {
System.out.println("######ProductManinApp created.#########");
}

public ProductManinApp(ProductService ps) {
	this.ps = ps;
System.out.println("ProductManinApp param constructor....");
}
	


public void setPs(ProductService ps) {
	this.ps = ps;
	System.out.println("ProductManinApp setPs method.........");
}


public void addProduct(Product product){

	if(ps.addProduct(product))
		System.out.println("Product added successfully............");
	else
		System.out.println("Problem in adding the product");
}


public void updateProduct(Product product){

	if(ps.updateProduct(product))
		System.out.println("Product updated successfully............");
	else
		System.out.println("Problem in updating the product");
}


public void removeProduct(int productId){

	if(ps.deleteProduct(productId))
		System.out.println("Product deleted successfully............");
	else
		System.out.println("Problem in deleting the product");
}



public void showProduct(int productId){

	Product product=ps.getProduct(productId);
	
	if(product!=null)
		System.out.println("Product Details \n===================="+product);
	else
		System.out.println("Problem in shwoing the product");
}



public void showAllProducts(){
System.out.println("All Products\n=======================================");

for(Product product:ps.getAllProducts())
	System.out.println(product);
}
	

public static void main(String[] args) {

	
	MapProductDaoImpl mpdi=new MapProductDaoImpl();
	
	ProductServiceImpl psi=new ProductServiceImpl(mpdi); //constructor
	
	ProductManinApp pms=new ProductManinApp();
	
	pms.setPs(psi);//setter
	
	
	pms.showAllProducts();
	
	
	
}
	
}
