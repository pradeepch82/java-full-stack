
Customer
========

customerId (auto generated)
firstName
lastName
gender
email
address
city
state



CustomerMainApp
         CustomerService
                 CustomerDao
                          CustomerMap







Product
========
productId (auto genrated)
productName
price



ProductMainApp
         ProductService
                 ProductDao
                          ProductMap






