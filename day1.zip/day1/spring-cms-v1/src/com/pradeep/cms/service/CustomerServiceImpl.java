package com.pradeep.cms.service;

import java.util.List;

import com.pradeep.cms.dao.CustomerDao;
import com.pradeep.cms.model.Customer;

public class CustomerServiceImpl implements CustomerService {

	
private CustomerDao customerDao; //dependency


	
public CustomerServiceImpl() {
System.out.println("CustomerServiceImpl created....");
}
	
	
  //constructor injection
	public CustomerServiceImpl(CustomerDao customerDao) {
	this.customerDao = customerDao;
	System.out.println("CustomerServiceImpl param costrucxtor created....");
   	}

	
	//setter injection
	public void setCustomerDao(CustomerDao customerDao) {
		this.customerDao = customerDao;
	
		System.out.println("CustomerServiceImpl setCustomerDao created....");
	   	}




	@Override
	public boolean addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return customerDao.addCustomer(customer);
	}

	@Override
	public boolean removeCustomer(int customerId) {
		// TODO Auto-generated method stub
		return customerDao.removeCustomer(customerId);
	}

	@Override
	public boolean updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return customerDao.updateCustomer(customer);
	}

	@Override
	public Customer getCustomer(int customerId) {
		// TODO Auto-generated method stub
		return customerDao.getCustomer(customerId);
	}

	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return customerDao.getAllCustomers();
	}

}
