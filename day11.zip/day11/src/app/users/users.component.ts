import { Component, OnInit } from '@angular/core';
import { UsersService } from '../services/users.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

 title="All Users";

 users:any;
 
 message="";




  constructor(private us:UsersService) { 
    console.log(" ========== UsersComponent created====== ");
 }

 ngOnInit(): void {
   this.getAllUsers();
   console.log(" ========== UsersComponent initialized====== ");
 }
 
 ngOnDestroy(): void {
   console.log(" ========== UsersComponent destroyed====== ");
 }


 getAllUsers(){
  this.us.getAllUsers()
         .subscribe(response=>this.users=response,error=>this.message=error);
 }


}
