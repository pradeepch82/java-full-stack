import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AngularBasicsComponent } from './angular-basics/angular-basics.component';
import { TechnologiesComponent } from './technologies/technologies.component';
import { AngularPipesComponent } from './angular-pipes/angular-pipes.component';
import { HomeComponent } from './home/home.component';
import { CaseStudyComponent } from './case-study/case-study.component';
import { UsersComponent } from './users/users.component';
import { PostsComponent } from './posts/posts.component';
import { TodosComponent } from './todos/todos.component';
import { AlbumsComponent } from './albums/albums.component';
import { PhotosComponent } from './photos/photos.component';
import { CommentsComponent } from './comments/comments.component';


const routes: Routes = [
  {path:'basics',component:AngularBasicsComponent},
  {path:'pipes',component:AngularPipesComponent},
  {path:'technologies',component:TechnologiesComponent},
  {path:'home',component:HomeComponent},
  {path:'casestudy',component:CaseStudyComponent,

   children:[
    {path:'users',component:UsersComponent},
    {path:'posts',component:PostsComponent},
    {path:'todos',component:TodosComponent},
    {path:'albums',component:AlbumsComponent},
    {path:'photos',component:PhotosComponent},
    {path:'comments',component:CommentsComponent},
   ]
  },
  
  {path:'**',redirectTo:"home"},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
