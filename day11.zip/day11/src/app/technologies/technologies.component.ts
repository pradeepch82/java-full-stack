import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-technologies',
  templateUrl: './technologies.component.html',
  styleUrls: ['./technologies.component.css']
})
export class TechnologiesComponent implements OnInit {

  title="Top 5 technologies";

  technologies=[
    {id:1,name:'Java',likes:0,dislikes:0},
    {id:2,name:'AWS',likes:0,dislikes:0},
    {id:3,name:'Angular',likes:0,dislikes:0},
    {id:4,name:'Docker',likes:0,dislikes:0},
    {id:5,name:'Spring Boot',likes:0,dislikes:0}
    ];

  


    incrementLikes(t){
       t.likes++;
    }

    incrementDislikes(t){
         t.dislikes++;
    }




  constructor() { 
    console.log(" ========== TechnologiesComponent created====== ");
 }

 ngOnInit(): void {
   console.log(" ========== TechnologiesComponent initialized====== ");
 }
 
 ngOnDestroy(): void {
   console.log(" ========== TechnologiesComponent destroyed====== ");
 }

}
