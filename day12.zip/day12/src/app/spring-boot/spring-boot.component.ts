import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-spring-boot',
  templateUrl: './spring-boot.component.html',
  styleUrls: ['./spring-boot.component.css']
})
export class SpringBootComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
