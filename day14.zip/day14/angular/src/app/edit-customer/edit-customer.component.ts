import { Component, OnInit } from '@angular/core';
import { SpringBootService } from '../services/spring-boot.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-edit-customer',
  templateUrl: './edit-customer.component.html',
  styleUrls: ['./edit-customer.component.css']
})
export class EditCustomerComponent implements OnInit {

  title="Edit  Customer";

  customer:any;
 
  message="";
  
  customerId=0;

 
   constructor(private sbs:SpringBootService,private route:ActivatedRoute,private router:Router) {
     console.log("===========EditCustomerComponent created===============");
    }
 
   ngOnInit() {

    this.customerId=this.route.snapshot.queryParams.customerId;

    if(this.customerId)
     this.getCustomerById();

    
    console.log("===========EditCustomerComponent initialized==============="+this.customerId);
     
     
     
   }
  
   ngOnDestroy() {
     console.log("===========EditCustomerComponent destroyed===============");
   }
 

   getCustomerById(){
    this.sbs.getCustomerById(this.customerId)
    .subscribe(response=>this.customer=response
     ,
     error=>this.message=error)
   }
 
 
   updateCustomer(){
      this.sbs.updateCustomerById(this.customerId,this.customer)
            .subscribe(response=>this.router.navigate(['/springboot'])
             ,
             error=>this.message=error)
    }

}
