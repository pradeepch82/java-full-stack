import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SpringBootService } from '../services/spring-boot.service';

@Component({
  selector: 'app-spring-boot',
  templateUrl: './spring-boot.component.html',
  styleUrls: ['./spring-boot.component.css']
})
export class SpringBootComponent implements OnInit {

  title="Angular Spring Boot Integration";

  customers:any;
 
  message="";
 

 
   constructor(private sbs:SpringBootService,private router:Router) {
     console.log("===========SpringBootComponent created===============");
    }
 
   ngOnInit() {

    
    console.log("===========SpringBootComponent initialized===============");
     
     this.getAllCustomers();
     
     
     
   }
  
   ngOnDestroy() {
     console.log("===========SpringBootComponent destroyed===============");
   }
 
 
 
   getAllCustomers(){
   
     this.sbs.getAllCustomers()
            .subscribe(response=>this.customers=response
             ,
             error=>this.message=error)
 
   }
}
