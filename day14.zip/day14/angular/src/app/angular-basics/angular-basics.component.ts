import { Component, OnInit, OnDestroy } from '@angular/core';
import { Observable, Subscriber } from 'rxjs';

@Component({
  selector: 'app-angular-basics',
  templateUrl: './angular-basics.component.html',
  styleUrls: ['./angular-basics.component.css']
})
export class AngularBasicsComponent implements OnInit,OnDestroy {
 
  title='Angular 8 Basics';//string
  colors=['RED','MAGENTA','BLUE','PURPLE'];//array
  day=1;//number
  min:number=1;
  max=8;

time=new Observable<string>((s:Subscriber<string>)=>{
  
  setInterval(()=>{
    s.next(new Date().toLocaleString());
    },1000);

});


  show=true; //boolean
  hide:boolean=false;//boolean

 employee={
    id:101,
    name:'Pradeep chinchole',
    salary:2345788.4353444,
    variable:0.12,
    doj:new Date(),
    pan:'amxpc9867G',
    mobile:'9787654262'
  };//object



  constructor() { 
    console.log("############ AngularBasicsComponent  created #############");

  }

  ngOnInit(): void {
    console.log("############ AngularBasicsComponent  initialized #############");
    
  }

  ngOnDestroy(): void {
    console.log("############ AngularBasicsComponent  destroyed #############");
    }

  
  
    ngDoCheck() {
      console.log("############ AngularBasicsComponent  ngDoCheck #############");
    }

    
    ngOnChanges() {
      console.log("############ AngularBasicsComponent  ngOnChanges #############");
    }
    
    ngAfterContentInit() {
      console.log("############ AngularBasicsComponent  ngAfterContentInit #############");
    }
    
    ngAfterContentChecked() {
      console.log("############ AngularBasicsComponent  ngAfterContentChecked #############");
    }
    
    ngAfterViewChecked() {
      console.log("############ AngularBasicsComponent  ngAfterViewChecked #############");
    }
    
    ngAfterViewInit() {
      console.log("############ AngularBasicsComponent  ngAfterViewInit #############");
    }
  

  showHide(){
    this.hide=!this.hide;
  }


}
