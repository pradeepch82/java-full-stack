import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {

  message="Hello Child";

  childMessage="";


  constructor() { 
    console.log("############ ParentComponent  created #############");
  
  }
  
  ngOnInit(): void {
    console.log("############ ParentComponent  initialized #############");
    
  }
  
  ngOnDestroy(): void {
    console.log("############ ParentComponent  destroyed #############");
    }
  
  
  
    ngDoCheck() {
      console.log("############ ParentComponent  ngDoCheck #############");
    }
  
    
    ngOnChanges() {
      console.log("############ ParentComponent  ngOnChanges #############");
    }
    
    ngAfterContentInit() {
      console.log("############ ParentComponent  ngAfterContentInit #############");
    }
    
    ngAfterContentChecked() {
      console.log("############ ParentComponent  ngAfterContentChecked #############");
    }
    
    ngAfterViewChecked() {
      console.log("############ ChildComponent  ngAfterViewChecked #############");
    }
    
    ngAfterViewInit() {
      console.log("############ ParentComponent  ngAfterViewInit #############");
    }
  
  
}
