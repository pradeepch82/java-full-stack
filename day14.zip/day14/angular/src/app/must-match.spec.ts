import { MustMatch } from './must-match';

describe('MustMatch', () => {
  it('should create an instance', () => {
    expect(new MustMatch()).toBeTruthy();
  });
});
