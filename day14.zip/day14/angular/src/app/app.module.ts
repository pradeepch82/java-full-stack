import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AngularBasicsComponent } from './angular-basics/angular-basics.component';
import { TechnologiesComponent } from './technologies/technologies.component';
import { AngularPipesComponent } from './angular-pipes/angular-pipes.component';
import { HomeComponent } from './home/home.component';
import { CaseStudyComponent } from './case-study/case-study.component';
import { UsersComponent } from './users/users.component';
import { PostsComponent } from './posts/posts.component';
import { CommentsComponent } from './comments/comments.component';
import { TodosComponent } from './todos/todos.component';
import { AlbumsComponent } from './albums/albums.component';
import { PhotosComponent } from './photos/photos.component';
import { UsersListComponent } from './users-list/users-list.component';
import { UsersTableComponent } from './users-table/users-table.component';
import { PostsService } from './services/posts.service';
import {Ng2SearchPipeModule} from "ng2-search-filter";
import { GenderPipe } from './pipes/gender.pipe';
import { OrderByPipe } from './pipes/order-by.pipe';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ViewChildComponent } from './view-child/view-child.component';
import { CustomDirectivesComponent } from './custom-directives/custom-directives.component';
import { NestedComponent } from './nested/nested.component';
import { SpringBootComponent } from './spring-boot/spring-boot.component';
import { UsersService } from './services/users.service';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { CountryComponent } from './country/country.component';
import { StateComponent } from './state/state.component';
import { CityComponent } from './city/city.component';
import { FgColorDirective } from './directives/fg-color.directive';
import { BgColorDirective } from './directives/bg-color.directive';
import { NgShowDirective } from './directives/ng-show.directive';
import { NgHideDirective } from './directives/ng-hide.directive';
import { NumberComponent } from './number/number.component';
import { MustMatchDirective } from './directives/must-match.directive';
import { AddressModule } from './address/address.module';
import { AddCustomerComponent } from './add-customer/add-customer.component';
import { EditCustomerComponent } from './edit-customer/edit-customer.component';
import { DeleteCustomerComponent } from './delete-customer/delete-customer.component';


@NgModule({
  declarations: [//components,directive,pipes
    AppComponent, AngularBasicsComponent, TechnologiesComponent,
     AngularPipesComponent, HomeComponent,
      CaseStudyComponent, UsersComponent,
       PostsComponent, CommentsComponent, TodosComponent, AlbumsComponent, PhotosComponent, UsersListComponent, UsersTableComponent, GenderPipe, OrderByPipe, LoginComponent, RegisterComponent, ViewChildComponent, CustomDirectivesComponent, NestedComponent, SpringBootComponent, ParentComponent, ChildComponent, CountryComponent, StateComponent, CityComponent, FgColorDirective, BgColorDirective, NgShowDirective, NgHideDirective, NumberComponent, MustMatchDirective, AddCustomerComponent, EditCustomerComponent, DeleteCustomerComponent
  ],
  imports: [//modules
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    Ng2SearchPipeModule,
    HttpClientModule,
    ReactiveFormsModule,
  //  AddressModule
  ],
  //providers: [UsersService],//services  prior to angular 5
  bootstrap: [AppComponent]//components,

 // bootstrap: [AppComponent,AngularBasicsComponent,AngularPipesComponent,TechnologiesComponent]//components
})
export class AppModule { }
