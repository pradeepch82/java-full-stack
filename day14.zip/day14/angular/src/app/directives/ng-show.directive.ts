import { Directive, TemplateRef, ViewContainerRef, Input } from '@angular/core';

@Directive({
  selector: '[ngShow]'
})
export class NgShowDirective {

  constructor(private t:TemplateRef<any>,private vcr:ViewContainerRef) { }


  @Input()
  set ngShow(value:boolean){
  console.log("In setNgShow  :"+value);
  if(value)
  this.vcr.createEmbeddedView(this.t);
  else
  this.vcr.clear();
  }


}
