import { MustMatchDirective } from './must-match.directive';

describe('MustMatchDirective', () => {
  it('should create an instance', () => {
    const directive = new MustMatchDirective();
    expect(directive).toBeTruthy();
  });
});
