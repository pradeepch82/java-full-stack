import { Injectable } from '@angular/core';
import { CanActivate, CanActivateChild, CanDeactivate, CanLoad, Route, UrlSegment, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';


@Injectable({
  providedIn: 'root'
})
export class MultiGuard implements CanActivate, CanActivateChild, CanDeactivate<unknown>, CanLoad {
  
  

  constructor(private router:Router)
  {}  
  
  
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
  
     var email=sessionStorage.getItem("email");  

     if(email!=null){
       return true;
     }
     else{
       alert("Please Login First");
       this.router.navigate(['/login']);
      return false;
    }
  }
  
  
  
  
  canActivateChild(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

      var email=sessionStorage.getItem("email");  

      if(email=='pradeep@gmail.com'){
        return true;
      }
      else{
        alert("You are not allowed to visit this section,Please login with valid credentials");
        this.router.navigate(['/login']);
       return false;
     }
 

  }
  canDeactivate(
    component: unknown,
    currentRoute: ActivatedRouteSnapshot,
    currentState: RouterStateSnapshot,
    nextState?: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    return confirm("Do you want to leave this Page?");
  }
  canLoad(
    route: Route,
    segments: UrlSegment[]): Observable<boolean> | Promise<boolean> | boolean {
      return confirm("Do you want to load this Address Module?");
 
  }
}
