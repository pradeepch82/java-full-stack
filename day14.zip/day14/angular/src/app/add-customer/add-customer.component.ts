import { Component, OnInit } from '@angular/core';
import { SpringBootService } from '../services/spring-boot.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.css']
})
export class AddCustomerComponent implements OnInit {

  title="Add Customer";

  customer:any;
 
  message="";
 

 
   constructor(private sbs:SpringBootService,private router:Router) {
     console.log("===========AddCustomerComponent created===============");
    }
 
   ngOnInit() {
      this.customer={
customerId:0,
firstName:'',
lastName:'',
email:'',
gender:'',
address:'',
city:'',
state:''
 };
    
    console.log("===========AddCustomerComponent initialized===============");
     
     
     
   }
  
   ngOnDestroy() {
     console.log("===========AddCustomerComponent destroyed===============");
   }
 
 
 
   addCustomer(){
      this.sbs.addCustomer(this.customer)
            .subscribe(response=>this.router.navigate(['/springboot'])
             ,
             error=>this.message=error)
    }

}
