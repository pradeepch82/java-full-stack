import { Component, OnInit } from '@angular/core';
import { PhotosService } from '../services/photos.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-photos',
  templateUrl: './photos.component.html',
  styleUrls: ['./photos.component.css']
})
export class PhotosComponent implements OnInit {

  title="Photos Table";

  photos:any;
 
  message="";
  
  albumId=0;


 
   constructor(private ps1:PhotosService,private route:ActivatedRoute) {
     console.log("===========UsersTableComponent created===============");
    }
 
   ngOnInit() {

    this.albumId=this.route.snapshot.queryParams.albumId;
    console.log("===========UsersTableComponent initialized==============="+this.albumId);
     
 
    if(this.albumId)
     this.getAllPhotosByAlbumId();
     else
     this.getAllPhotos();
     
     
     
   }
  
   ngOnDestroy() {
     console.log("===========UsersTableComponent destroyed===============");
   }
 
 
 
   getAllPhotos(){
   
     this.ps1.getAllPhotos()
            .subscribe(response=>this.photos=response,
             error=>this.message=error)
 
   }


   getAllPhotosByAlbumId(){
   
    this.ps1.getPhotosByAlbumId(this.albumId)
           .subscribe(response=>this.albumId=response,
            error=>this.message=error)

  }

}
