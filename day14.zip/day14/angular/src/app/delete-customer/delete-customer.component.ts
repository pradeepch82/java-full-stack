import { Component, OnInit } from '@angular/core';
import { SpringBootService } from '../services/spring-boot.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-delete-customer',
  templateUrl: './delete-customer.component.html',
  styleUrls: ['./delete-customer.component.css']
})
export class DeleteCustomerComponent implements OnInit {

  title="Delete Customer";

   
  message="";
  
  customerId=0;

 
   constructor(private sbs:SpringBootService,private route:ActivatedRoute,private router:Router) {
     console.log("===========DeleteCustomerComponent created===============");
    }
 
   ngOnInit() {

    this.customerId=this.route.snapshot.params.id;

    if(this.customerId)
     this.deleteCustomerById();

    
    console.log("===========DeleteCustomerComponent initialized==============="+this.customerId);
     
     
     
   }
  
   ngOnDestroy() {
     console.log("===========DeleteCustomerComponent destroyed===============");
   }
 

   deleteCustomerById(){
    this.sbs.deleteCustomerById(this.customerId)
    .subscribe(response=>this.router.navigate(['/springboot'])
    ,
     error=>this.message=error)
   }
  


}
