import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export class AddressModule { 

  constructor(){
    console.log("#################  AddressModule created  ##################")
  }

}
