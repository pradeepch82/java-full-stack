import { TestBed } from '@angular/core/testing';

import { SpringBootService } from './spring-boot.service';

describe('SpringBootService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SpringBootService = TestBed.get(SpringBootService);
    expect(service).toBeTruthy();
  });
});
