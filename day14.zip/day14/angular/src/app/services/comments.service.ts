import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn:'root'
}) //before angular 5
export class CommnetsService {

  private baseURL="https://jsonplaceholder.typicode.com/comments";


  constructor(private http:HttpClient) { 

    console.log("CommnetsService created....");
  }


  getAllComments() :Observable<any> {
   return this.http.get(this.baseURL); 
  }


  
  getCommentByCommentId(commentId:number) :Observable<any> {
    return this.http.get(this.baseURL+"/"+commentId); 
   }

   getAllCommentsByPostId(postId:number) :Observable<any> {
    return this.http.get(this.baseURL+"?postId="+postId); 
   }
 

}
