package com.pradeep.cms.rest.controller;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.ContextLoaderListener;

import com.pradeep.cms.model.Customer;
import com.pradeep.cms.service.CustomerService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RequestMapping("/customers")
@RestController
public class CustomerRestController {

	@Qualifier("cmrsi")
	@Autowired
	private CustomerService cs; // dependency

	public CustomerRestController() {
		System.out.println("CustomerRestController created...");
	}

	@ApiResponses({ @ApiResponse(code = 404, message = "Invalid URL"),
			@ApiResponse(code = 401, message = "Not Authenticate"),
			@ApiResponse(code = 403, message = "Not Authorized"),
			@ApiResponse(code = 500, message = "Internal Server Error"),

	})

	@ApiOperation("Get all customers")

	@GetMapping
	public List<Customer> getAllCustomers() {
		return cs.getAllCustomers();
	}

	
	@ApiOperation("Get customer by id")

	@GetMapping("/{id}")
	public Customer getCustomer(@PathVariable("id") int customerId) {
		return cs.getCustomer(customerId);

	}

	@ApiOperation("Delete customer by id")
	@DeleteMapping("/{id}")
	public List<Customer> deleteCustomer(@PathVariable("id") int customerId) {
		cs.removeCustomer(customerId);
		return cs.getAllCustomers();

	}

	@ApiOperation("Update customer by id")
	@PutMapping("/{id}")
	public List<Customer> updateCustomer(@PathVariable("id") int customerId, @RequestBody Customer customer) {
		cs.updateCustomer(customer);
		return cs.getAllCustomers();

	}

	@ApiOperation("Add customer ")
	@PostMapping
	public List<Customer> addCustomer(@RequestBody Customer customer) {
		cs.addCustomer(customer);
		return cs.getAllCustomers();

	}

	@PostConstruct
	public void init() {
		System.out.println("........CustomerRestController initialized......");
	}

	@PreDestroy
	public void destroy() {
		System.out.println("........CustomerRestController destroyed......");
	}

}
